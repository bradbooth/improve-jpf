import java.util.Random;

public class Main {

	public static void main(String[] args) throws Exception {
		
		// Use up memory
		int NUM_OBJECTS_TO_CREATE = 10000;
		Object[] arr = new Object[NUM_OBJECTS_TO_CREATE ];
		for ( int i=0; i < NUM_OBJECTS_TO_CREATE ; i++) {
			arr[i] = new Object();
		}

		throw new Exception();

	}
}


